﻿namespace BottinToCSV
{
    public class Product
    {
        public string Code39 { get; set; }
        public string Nom { get; set; }
        public string Pqt { get; set; }
        public string Format { get; set; }
        public double PrixInitial { get; set; }
        public double PrixFinal { get; set; }
    }
}
